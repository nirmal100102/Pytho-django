from django.contrib.auth import get_user_model
from rest_framework import viewsets, status
from rest_framework.decorators import action
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.generics import ListAPIView

from .models import Client, Project
from .serializers import (
    ClientSerializer, ClientDetailSerializer,
    ProjectCreateSerializer, ProjectDetailSerializer
)

User = get_user_model()

class ClientViewSet(viewsets.ModelViewSet):
    queryset = Client.objects.all().order_by("id")
    permission_classes = [IsAuthenticated]
    filterset_fields = ["client_name"]
    search_fields = ["client_name"]
    ordering_fields = ["id", "client_name", "created_at"]

    def get_serializer_class(self):
        if self.action in ["retrieve"]:
            return ClientDetailSerializer
        return ClientSerializer

    def perform_create(self, serializer):
        serializer.save(created_by=self.request.user)

    def perform_update(self, serializer):
        serializer.save()

    @action(detail=True, methods=["post"], url_path="projects")
    def create_project(self, request, pk=None):
        # POST /api/clients/{id}/projects/
        # body: { "project_name": "...", "users": [1,2] }
        client = self.get_object()
        serializer = ProjectCreateSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        project = Project.objects.create(
            project_name=serializer.validated_data["project_name"],
            client=client,
            created_by=request.user,
        )
        users = serializer.validated_data.get("users", [])
        if users:
            project.users.set(users)
        project.save()
        out = ProjectDetailSerializer(project, context={"request": request})
        return Response(out.data, status=status.HTTP_201_CREATED)


class MyProjectsView(ListAPIView):
    serializer_class = ProjectDetailSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        return Project.objects.filter(users=self.request.user).order_by("id")
